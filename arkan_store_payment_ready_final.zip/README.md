# ARKAN STORE — Payment Ready

Versi ini sudah menyiapkan checkout Midtrans Snap dari backend sampai webhook.

## Alur pembayaran
1. Pembeli memilih paket dan mengisi data.
2. Backend membuat order dengan harga dari allowlist server (bukan harga dari browser).
3. Backend meminta Snap token ke Midtrans.
4. Pembeli membayar melalui Snap.
5. Midtrans mengirim webhook ke `/api/payment/webhook`.
6. Backend memverifikasi notifikasi melalui SDK Midtrans, mencocokkan nominal, lalu mengubah status menjadi `paid` dan order menjadi `diproses`.

## Setup Sandbox
```bash
npm install
cp .env.example .env
```
Isi `.env` dengan Sandbox Server Key dan Client Key dari dashboard merchant.

Jalankan:
```bash
npm start
```

Frontend Sandbox memakai:
`https://app.sandbox.midtrans.com/snap/snap.js`

## Webhook
Set Payment Notification URL di dashboard Midtrans ke:
`https://DOMAIN-KAMU/api/payment/webhook`

Gunakan HTTPS pada hosting publik.

## Production
Saat akun merchant sudah aktif untuk Production:
- `MIDTRANS_IS_PRODUCTION=true`
- ganti Server Key dan Client Key ke credential Production
- ganti script Snap menjadi `https://app.midtrans.com/snap/snap.js`
- set Payment Notification URL Production ke `https://DOMAIN-KAMU/api/payment/webhook`

Jangan pernah menaruh Server Key di frontend.

## Catatan produksi
`data/orders.json` dipakai untuk testing/small deployment. Untuk toko sungguhan, pindahkan order ke database (PostgreSQL/MySQL/etc.) dan tambahkan autentikasi/admin, backup, logging, rate limiting, serta workflow fulfilment setelah status `paid`.

### Sumber teknis
Dokumentasi Midtrans menyatakan token Snap dibuat dari backend, Snap ditampilkan di frontend, dan status pembayaran harus ditangani di backend. Webhook sebaiknya memakai HTTPS, verifikasi signature/notifikasi, mencocokkan status transaksi, dan dibuat idempotent.
