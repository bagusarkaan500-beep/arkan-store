require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const midtransClient = require('midtrans-client');

const app = express();
const PORT = process.env.PORT || 3000;
const IS_PRODUCTION = String(process.env.MIDTRANS_IS_PRODUCTION).toLowerCase() === 'true';
const DB_FILE = path.join(__dirname, 'data', 'orders.json');

const snap = new midtransClient.Snap({
  isProduction: IS_PRODUCTION,
  serverKey: process.env.MIDTRANS_SERVER_KEY || '',
  clientKey: process.env.MIDTRANS_CLIENT_KEY || ''
});

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

function readOrders(){
  if(!fs.existsSync(DB_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return []; }
}
function writeOrders(orders){
  fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
}
function orderId(){
  return 'ARK-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2,7).toUpperCase();
}

const PRICE_LIST = {
  'Top Up 250K Koin': 3000,
  'Top Up 1M Koin': 10000,
  'Top Up 3M Koin': 30000,
  'Joki Ring Basic': 50000,
  'Joki Ring Pro': 100000
};

app.post('/api/orders', (req,res)=>{
  const {service, name, gameid, detail} = req.body || {};
  if(!service || !name || !gameid) return res.status(400).json({error:'Data pesanan belum lengkap.'});
  if(!(service in PRICE_LIST)) return res.status(400).json({error:'Paket tidak valid atau belum memiliki harga tetap.'});

  const orders = readOrders();
  const order = {
    id: orderId(), service, price: PRICE_LIST[service], name, gameid,
    detail: detail || '', payment_status: 'pending', order_status: 'menunggu_pembayaran',
    created_at: new Date().toISOString()
  };
  orders.push(order); writeOrders(orders);
  res.json(order);
});

app.post('/api/payment/create', async (req,res)=>{
  try{
    const {order_id} = req.body || {};
    const orders = readOrders();
    const order = orders.find(x => x.id === order_id);
    if(!order) return res.status(404).json({error:'Pesanan tidak ditemukan.'});
    if(order.payment_status === 'paid') return res.status(400).json({error:'Pesanan sudah dibayar.'});

    const parameter = {
      transaction_details: { order_id: order.id, gross_amount: order.price },
      item_details: [{ id: order.service.toLowerCase().replace(/[^a-z0-9]+/g,'-'), price: order.price, quantity: 1, name: order.service.slice(0,50) }],
      customer_details: { first_name: String(order.name).slice(0,50) }
    };

    const transaction = await snap.createTransaction(parameter);
    order.snap_token = transaction.token;
    order.payment_created_at = new Date().toISOString();
    writeOrders(orders);
    res.json({order_id: order.id, token: transaction.token});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'Gagal membuat transaksi pembayaran. Pastikan credential Midtrans sudah diisi.'});
  }
});

app.get('/api/orders/:id',(req,res)=>{
  const order = readOrders().find(x => x.id === req.params.id);
  if(!order) return res.status(404).json({error:'Pesanan tidak ditemukan.'});
  res.json({id:order.id, service:order.service, price:order.price, payment_status:order.payment_status, order_status:order.order_status});
});

app.post('/api/payment/webhook', async (req,res)=>{
  try{
    // Official Midtrans notification verification: the SDK verifies the notification
    // against Midtrans using the confidential Server Key.
    const statusResponse = await snap.transaction.notification(req.body);
    const orderIdFromMidtrans = statusResponse.order_id;
    const orders = readOrders();
    const order = orders.find(x => x.id === orderIdFromMidtrans);
    if(!order) return res.status(404).json({error:'Pesanan tidak ditemukan.'});

    const transactionStatus = statusResponse.transaction_status;
    const fraudStatus = statusResponse.fraud_status;
    const statusCode = String(statusResponse.status_code || '');

    let paymentStatus = 'pending';
    if(transactionStatus === 'settlement' || (transactionStatus === 'capture' && fraudStatus !== 'deny')) paymentStatus = 'paid';
    else if(['deny','cancel','failure'].includes(transactionStatus)) paymentStatus = 'failed';
    else if(transactionStatus === 'expire') paymentStatus = 'expired';

    // Defense in depth: the amount received must match the server-side order amount.
    if(Number(statusResponse.gross_amount) !== Number(order.price)){
      return res.status(400).json({error:'Nominal pembayaran tidak sesuai pesanan.'});
    }

    order.payment_status = paymentStatus;
    order.transaction_status = transactionStatus;
    order.fraud_status = fraudStatus || null;
    order.status_code = statusCode;
    order.payment_type = statusResponse.payment_type || null;
    order.transaction_id = statusResponse.transaction_id || null;
    order.updated_at = new Date().toISOString();
    if(paymentStatus === 'paid') order.order_status = 'diproses';
    if(paymentStatus === 'failed' || paymentStatus === 'expired') order.order_status = 'pembayaran_gagal';
    writeOrders(orders);

    // TODO: after payment_status === 'paid', connect your fulfilment system/admin workflow.
    res.json({ok:true});
  }catch(err){
    console.error('Webhook verification failed:', err.message || err);
    res.status(400).json({error:'Webhook pembayaran tidak valid.'});
  }
});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT,()=>console.log(`ARKAN STORE running on port ${PORT} (${IS_PRODUCTION ? 'production' : 'sandbox'})`));
